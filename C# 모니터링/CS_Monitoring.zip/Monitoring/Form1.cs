﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;
using System.Timers;

namespace Monitoring
{
    public partial class Form1 : Form
    {
        private void Call_BarChart()
        {
            BarChart.ChartAreas.Clear(); BarChart.Series.Clear(); BarChart.Titles.Clear();

            BarChart.BackColor = Color.DarkGray;
            BarChart.ChartAreas.Add("Draw");
            BarChart.ChartAreas["Draw"].BackColor = Color.LightGray;

            //ChartArea Y축을 정보 설정, x 축은 출력 x
            BarChart.ChartAreas["Draw"].AxisY.Minimum = 0;
            BarChart.ChartAreas["Draw"].AxisY.Maximum = 20;
            BarChart.ChartAreas["Draw"].AxisY.Interval = 2;
            BarChart.ChartAreas["Draw"].AxisY.MajorGrid.LineColor = Color.LightGray;
            BarChart.ChartAreas["Draw"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;

            BarChart.ChartAreas["Draw"].AxisX.Enabled = AxisEnabled.False;

            // Title 정의
            BarChart.Titles.Add("BarChart");
            BarChart.Titles[0].Alignment = ContentAlignment.TopLeft;
            BarChart.Titles[0].BackColor = Color.DarkGray;
            BarChart.Titles[0].ForeColor = Color.Black;

            // Legend(범례) 추가 및 정의
            Legend barchart_legend = new Legend("BarChart_Legend");
            barchart_legend.BackColor = Color.DarkGray;

            BarChart.Legends.Add(barchart_legend);

            BarChart.Series.Add("Test");
            BarChart.Series[0].ChartType = SeriesChartType.Column; // 싱글 세로형 막대 차트
            BarChart.Series[0].Color = Color.Blue;
            BarChart.Series[0].Legend = "BarChart_Legend";
            BarChart.Series[0].LegendText = "sample";

            // 데이터 추가
            BarChart.Series[0].Points.AddY(1);

        }

        private void Call_LineChart()
        {
            LineChart.ChartAreas.Clear(); LineChart.Series.Clear(); LineChart.Titles.Clear();

            // LineChart
            LineChart.BackColor = Color.DarkGray;
            LineChart.ChartAreas.Add("Draw");
            LineChart.ChartAreas["Draw"].BackColor = Color.LightGray;

            //ChartArea Y축을 정보 설정, x 축은 출력 x
            LineChart.ChartAreas["Draw"].AxisY.Minimum = 0;
            LineChart.ChartAreas["Draw"].AxisY.Maximum = 20;
            LineChart.ChartAreas["Draw"].AxisY.Interval = 2;
            LineChart.ChartAreas["Draw"].AxisY.MajorGrid.LineColor = Color.Gray;
            LineChart.ChartAreas["Draw"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;

            LineChart.ChartAreas["Draw"].AxisX.Enabled = AxisEnabled.False;

            // Title 정의
            LineChart.Titles.Add("LineChart");
            LineChart.Titles[0].Alignment = ContentAlignment.TopLeft;
            LineChart.Titles[0].BackColor = Color.DarkGray;
            LineChart.Titles[0].ForeColor = Color.Black;

            // Legend(범례) 추가 및 정의
            Legend linechart_legend = new Legend("LineChart_Legend");
            linechart_legend.BackColor = Color.DarkGray;

            LineChart.Legends.Add(linechart_legend);

            LineChart.Series.Add("Test");
            LineChart.Series[0].ChartType = SeriesChartType.Line;
            LineChart.Series[0].Color = Color.Blue;
            LineChart.Series[0].Legend = "LineChart_Legend";
            LineChart.Series[0].LegendText = "sample";

            // 데이터 추가
            LineChart.Series[0].Points.AddY(1);
            LineChart.Series[0].Points.AddY(5);

            //int cnt = 0;
            //double y = 0.0;
            //for (double x = -20; x < 20; x += 1)
            //{
            //    if (x == -10)
            //        chart1.Series[0].Points.RemoveAt(5);

            //    if (cnt % 2 == 0)
            //        y += 0.2;
            //    else
            //        y -= 0.3;


            //    //q.Enqueue(new KeyValuePair<double, double>(x, y));
            //    chart1.Series["Sin"].Points.AddXY(x, y);

            //    //KeyValuePair<double, double> temp = q.Dequeue();
            //    // 
            //    //y = 0.0;
            //    //y = Math.Cos(x) / x;
            //    //chart1.Series["Cos"].Points.AddXY(x, y);
            //    cnt++;
            //}

        }

        private void Call_MultiBarChart()
        {
            MultiBarChart.ChartAreas.Clear(); MultiBarChart.Series.Clear(); MultiBarChart.Titles.Clear();

            // MultiBarChart (원하는 개수만큼 추가)
            MultiBarChart.BackColor = Color.DarkGray;
            MultiBarChart.ChartAreas.Add("Draw");
            MultiBarChart.ChartAreas["Draw"].BackColor = Color.LightGray;

            //ChartArea Y축을 정보 설정, x 축은 출력 x
            MultiBarChart.ChartAreas["Draw"].AxisY.Minimum = 0;
            MultiBarChart.ChartAreas["Draw"].AxisY.Maximum = 20;
            MultiBarChart.ChartAreas["Draw"].AxisY.Interval = 2;
            MultiBarChart.ChartAreas["Draw"].AxisY.MajorGrid.LineColor = Color.Gray;
            MultiBarChart.ChartAreas["Draw"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;

            MultiBarChart.ChartAreas["Draw"].AxisX.Enabled = AxisEnabled.False;

            // Title 정의
            MultiBarChart.Titles.Add("MultiBarChart");
            MultiBarChart.Titles[0].Alignment = ContentAlignment.TopLeft;
            MultiBarChart.Titles[0].BackColor = Color.DarkGray;
            MultiBarChart.Titles[0].ForeColor = Color.Black;

            // Legend(범례) 추가 및 정의
            Legend Multichart_legend = new Legend("MultiChart_Legend");
            Multichart_legend.BackColor = Color.DarkGray;

            MultiBarChart.Legends.Add(Multichart_legend);

            MultiBarChart.Series.Add("Test");
            MultiBarChart.Series[0].ChartType = SeriesChartType.Column;
            MultiBarChart.Series[0].Color = Color.Blue;
            MultiBarChart.Series[0].Legend = "MultiChart_Legend";
            MultiBarChart.Series[0].LegendText = "sample";

            MultiBarChart.Series[0].Points.AddY(1);
            MultiBarChart.Series[0].Points.AddY(5);

        }

        private void Call_PieChart()
        {
            PieChart.ChartAreas.Clear(); PieChart.Series.Clear(); PieChart.Titles.Clear();

            // PieChart
            PieChart.BackColor = Color.DarkGray;
            PieChart.ChartAreas.Add("Draw");
            PieChart.ChartAreas["Draw"].BackColor = Color.LightGray;

            //ChartArea Y축을 정보 설정, x 축은 출력 x
            PieChart.ChartAreas["Draw"].AxisY.Minimum = 0;
            PieChart.ChartAreas["Draw"].AxisY.Maximum = 20;
            PieChart.ChartAreas["Draw"].AxisY.Interval = 2;
            PieChart.ChartAreas["Draw"].AxisY.MajorGrid.LineColor = Color.Gray;
            PieChart.ChartAreas["Draw"].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;

            PieChart.ChartAreas["Draw"].AxisX.Enabled = AxisEnabled.False;

            // Title 정의
            PieChart.Titles.Add("PieChart");
            PieChart.Titles[0].Alignment = ContentAlignment.TopLeft;
            PieChart.Titles[0].BackColor = Color.DarkGray;
            PieChart.Titles[0].ForeColor = Color.Black;

            // Legend(범례) 추가 및 정의
            Legend Piechart_legend = new Legend("PieChart_Legend");
            Piechart_legend.BackColor = Color.DarkGray;

            PieChart.Legends.Add(Piechart_legend);

            PieChart.Series.Add("Test");
            PieChart.Series[0].ChartType = SeriesChartType.Pie;
            PieChart.Series[0].Color = Color.Blue;
            PieChart.Series[0].Legend = "PieChart_Legend";
            PieChart.Series[0].LegendText = "sample";

            PieChart.Series[0].Points.AddY(10);
            PieChart.Series[0].Points.AddY(10);
            PieChart.Series[0].Points.AddY(1);
            PieChart.Series[0].Points.AddY(1);
        }


        int x = 0;

        System.Drawing.SolidBrush power_brush, memory_brush, cpu_brush;
        System.Drawing.Graphics power_graphic, memory_graphic, cpu_graphic;
        Label label;

        public Form1()
        {
            InitializeComponent();
            //test();

        }

        public void test()
        {
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Interval = 1000;// 1 시간
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
            timer.Start();
           
        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            this.Invalidate();
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            /*
                Label 을 출력하기 위한 사각형 색상 및 위치 결정
            */
            power_brush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
            power_graphic = this.CreateGraphics();
            power_graphic.FillRectangle(power_brush, new Rectangle(10, 10, 100, 150));

            memory_brush = new System.Drawing.SolidBrush(System.Drawing.Color.Blue);
            memory_graphic = this.CreateGraphics();
            memory_graphic.FillRectangle(memory_brush, new Rectangle(10, 170, 100, 150));

            cpu_brush = new System.Drawing.SolidBrush(System.Drawing.Color.Blue);
            cpu_graphic = this.CreateGraphics();
            cpu_graphic.FillRectangle(cpu_brush, new Rectangle(10, 330, 100, 150));

            /*
                각 사각형위에 출력될 Label 생성 및 위치 결정
            */

            //label = new Label();
            //label.BackColor = Color.Red;
            //label.Location = new System.Drawing.Point(5, 5);
            //label.Size = new System.Drawing.Size(20, 20);
            //label.Text = "bb";
            //label.Parent = this;

            // 용도가 무엇??
            //base.OnPaint(e);


            //------------------------------------------

            Call_BarChart();

            Call_LineChart();

            Call_MultiBarChart();

            Call_PieChart();
        }

    }
}

    
